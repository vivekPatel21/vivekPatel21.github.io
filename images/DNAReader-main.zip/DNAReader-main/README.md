Will read a strand of DNA and seperate it as it can. It will give error messages if there is a space in the strand or if something is not a acid found in DNA.
 
